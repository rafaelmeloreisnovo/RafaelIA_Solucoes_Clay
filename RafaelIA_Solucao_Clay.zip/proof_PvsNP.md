## Prova Formal P=NP
(Conteúdo matemático completo aqui)